using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour 
{
    [Header("Configuracion")]
    [SerializeField] private float velocidadMovimiento;
    private CharacterController characterController;

    private void Awake()
    {
        characterController = GetComponent<CharacterController>();
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        MoverPersonaje();

    }

    private void MoverPersonaje()
    {
        Vector3 nuevaPos = new Vector3(x: 0f, y: 0f, z: velocidadMovimiento);
        characterController.Move(motion: nuevaPos * Time.deltaTime);

    }







}
